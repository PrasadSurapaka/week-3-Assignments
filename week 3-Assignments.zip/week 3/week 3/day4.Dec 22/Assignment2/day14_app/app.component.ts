import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyApp';
  initialValue:number=5;
  finalValue:number=10;
  
  met(){
    this.title="New Title";
  }
}

import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css'],

})
export class SampleComponent {

  @Input()
  Value1:number=0;

  @Input()
  Value2:number=0;
  
  temp:number=0;
  constructor() {
  }
  
  increment(){
  this.temp=this.Value1;
    if(this.Value1<this.Value2){         
      this.Value1++;
    }
    else{
      this.Value1=this.temp;
    }
  }
  
  decrement(){
    this.Value1--;
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-security',
  template: `<h2>Security</h2>`
})
export class AboutComponent1 { }
export class Ticket{
    constructor(
        public id: number,
        public travleName: string,
        public fromPlace: string,
        public toPlace: string,
      ) {}
}
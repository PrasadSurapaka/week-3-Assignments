import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'filterData'
})

export class FilterData implements PipeTransform {
    transform(items:any[], args:string,tmatch:boolean){
        if (typeof items === 'object') {
            var allArray=[];
            var resultArray: any[]=[];
            var resultArray2 = [];
            if (args.length === 0) {
                resultArray = items;
                console.log('in if');
            }

            else {
                for (let item of items) {
                    allArray.push(item);
                    if (item != null  && item.match(new RegExp(''+args, 'i')) && tmatch) {
                        resultArray.push(item);
                        console.log(item);
                        }
                }
            }

            if(tmatch==true){
                return resultArray;
            }
            else{
                resultArray2=allArray.filter(item => !resultArray.includes(item))
                return resultArray2;
            }
            //allArray= allArray.filter(item => !resultArray.includes(item))
            // const newArr = namesArr.filter((name) => {
            //     // return those elements not in the namesToDeleteSet
            //     return !namesToDeleteSet.has(name);
            //   });

            // console.log('returning from outer if');
            // return resultArray;
                    
            // return resultArray2;
            // return null;
            // resultArray2=allArray.filter((name)=>{
            //    return !resultArray.has(name);
            //  });
            //return (tmatch ? resultArray : allArray.reduce(resultArray));
         //   return resultArray;

        }
        else {
            console.log('returning null');
            return null;
        }

    }

}
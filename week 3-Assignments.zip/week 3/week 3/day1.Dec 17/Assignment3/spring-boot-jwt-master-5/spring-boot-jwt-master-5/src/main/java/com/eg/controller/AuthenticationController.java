package com.eg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.eg.config.JwtTokenUtil;
import com.eg.model.*;
import com.eg.service.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/token")
public class AuthenticationController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/generate-token", method = RequestMethod.POST)
    public ApiResponse<AuthToken> register(@RequestBody LoginUser loginUser) throws AuthenticationException {

        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        final User user = userService.findOne(loginUser.getUsername());
        final String token = jwtTokenUtil.generateToken(user);
        System.out.println("Role is:"+user.getRole());
        return new ApiResponse<>(200, "success",new AuthToken(token, user.getUsername(), user.getRole()));
    }
    
    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public String signup(@RequestBody LoginUser loginUser, HttpServletRequest hsr) throws AuthenticationException {
    	System.out.println("Remote addr:"+hsr.getRemoteAddr()+":::"+hsr.getRemoteHost());
    	UserDto udto = new UserDto();
    	udto.setUsername(loginUser.getUsername());
    	udto.setPassword(loginUser.getPassword());
    	udto.setAge(23);
    	udto.setFirstName("firstName");
    	udto.setLastName("lastName");
        final User user = userService.save(udto);
        return "Done";
    }
    
    @RequestMapping(value = "/generate-token/time/{timelimit}", method = RequestMethod.POST)
    public ApiResponse<AuthToken> registerValidTime(@PathVariable long timelimit,@RequestBody LoginUser loginUser) throws AuthenticationException {

        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        final User user = userService.findOne(loginUser.getUsername());
        final String token = jwtTokenUtil.generateToken(user,timelimit);
        //final String token = jwtTokenUtil.generateToken(user);
        System.out.println("Role is:"+user.getRole());
        return new ApiResponse<>(200, "success",new AuthToken(token, user.getUsername(), user.getRole()));
    }
    

}

package com.method.spring.security.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;

@Component
class LoanService{
    
    @PreAuthorize("permitAll()")
    public String anonymous() {
        return "Hello World!!!";
    }
    
    @PreAuthorize("hasRole('ROLE_MANAGER')")
   // @PreAuthorize({"ROLE_MANAGER"})
	public String approveLoan() {		
		return "Manager Welcome Page";
		
	}
}

@RestController
@RequestMapping("/loan")
public class BankController {

	@Autowired
	LoanService lsc;
	
    @GetMapping("needLoan")
    @PermitAll
    public String needLoan() {
        return "Welcome to Bank!!!";
    }

    @GetMapping("approveLoan")
    public String approveLoan() {
        return lsc.approveLoan();
    }
}

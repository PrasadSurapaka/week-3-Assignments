function getseries(){
    let first = 0, second = 1, next_no;
    var n= document.getElementById("val1").value;
    for(let i=1;i<=n;i++){
       document.getElementById("demo").innerHTML += "<br>" + first;
      
        next_no= first+second;
        first=second;
        second=next_no;
    }
}
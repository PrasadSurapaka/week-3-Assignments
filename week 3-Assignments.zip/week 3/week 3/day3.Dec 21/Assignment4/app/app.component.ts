import { Component } from '@angular/core';
import { NewSService } from './new-s.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyApp';

  constructor(private serv:NewSService){
  //  console.log("Invoking Service" + serv.met())
  }
  
  met1(){
    this.title="New Title";
    console.log("Invoking Service" + this.serv.met())
  
  }
}

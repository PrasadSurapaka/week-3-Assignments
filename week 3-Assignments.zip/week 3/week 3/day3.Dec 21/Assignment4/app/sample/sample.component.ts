import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent {

  value:number=0;
  constructor() { }

  increment(){
    this.value++;
  }
  
  decrement(){
    this.value--;
  }
}
